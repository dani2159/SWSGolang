package main

import "SWSGolang/routers"

func main() {
	routers.SetupRouter().Run()
}
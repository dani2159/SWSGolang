package common

const (
	Host     = "localhost"
	Port     = 5544
	User     = "postgres"
	Password = "Dns215900"
	DBname   = "db_books"
)
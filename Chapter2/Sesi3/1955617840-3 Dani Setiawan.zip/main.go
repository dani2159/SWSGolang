package main

import "SWSGolang/app/router"

func main() {
	router.SetupRouter().Run()
}